
    const ctx = document.getElementById("canvas").getContext("2d");
    
        ctx.beginPath();
        ctx.strokeStyle = "rgb(0,190,190)";

        ctx.arc(25, 25, 10, 0, 2 * Math.PI, true);


        ctx.stroke();
        function draw() {
            const ctx = document.getElementById("canvas").getContext("2d");
            ctx.font = "48px serif";
            ctx.fillText("Hello world", 10, 50);
          }


          const ctx = document.getElementById("canvas").getContext("2d");
          ctx.font = "48px serif";
          ctx.strokeText("Hello world", 10, 50);
