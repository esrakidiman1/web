        function MetinDegistir2() {
          document.getElementById("metin").innerHTML = "Merhaba";
        }